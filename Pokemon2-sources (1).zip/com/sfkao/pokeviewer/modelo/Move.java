
package com.sfkao.pokeviewer.modelo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.Parcelable.Creator;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

@Generated("jsonschema2pojo")
public class Move implements Serializable, Parcelable
{

    @SerializedName("move")
    @Expose
    private Move__1 move;
    @SerializedName("version_group_details")
    @Expose
    private List<VersionGroupDetail> versionGroupDetails = new ArrayList<VersionGroupDetail>();
    public final static Creator<Move> CREATOR = new Creator<Move>() {


        @SuppressWarnings({
            "unchecked"
        })
        public Move createFromParcel(android.os.Parcel in) {
            return new Move(in);
        }

        public Move[] newArray(int size) {
            return (new Move[size]);
        }

    }
    ;
    private final static long serialVersionUID = 2182368194369134958L;

    protected Move(android.os.Parcel in) {
        this.move = ((Move__1) in.readValue((Move__1.class.getClassLoader())));
        in.readList(this.versionGroupDetails, (com.sfkao.pokeviewer.modelo.VersionGroupDetail.class.getClassLoader()));
    }

    public Move() {
    }

    public Move__1 getMove() {
        return move;
    }

    public void setMove(Move__1 move) {
        this.move = move;
    }

    public List<VersionGroupDetail> getVersionGroupDetails() {
        return versionGroupDetails;
    }

    public void setVersionGroupDetails(List<VersionGroupDetail> versionGroupDetails) {
        this.versionGroupDetails = versionGroupDetails;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Move.class.getName()).append('@').append(Integer.toHexString(System.identityHashCode(this))).append('[');
        sb.append("move");
        sb.append('=');
        sb.append(((this.move == null)?"<null>":this.move));
        sb.append(',');
        sb.append("versionGroupDetails");
        sb.append('=');
        sb.append(((this.versionGroupDetails == null)?"<null>":this.versionGroupDetails));
        sb.append(',');
        if (sb.charAt((sb.length()- 1)) == ',') {
            sb.setCharAt((sb.length()- 1), ']');
        } else {
            sb.append(']');
        }
        return sb.toString();
    }

    @Override
    public int hashCode() {
        int result = 1;
        result = ((result* 31)+((this.move == null)? 0 :this.move.hashCode()));
        result = ((result* 31)+((this.versionGroupDetails == null)? 0 :this.versionGroupDetails.hashCode()));
        return result;
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Move) == false) {
            return false;
        }
        Move rhs = ((Move) other);
        return (((this.move == rhs.move)||((this.move!= null)&&this.move.equals(rhs.move)))&&((this.versionGroupDetails == rhs.versionGroupDetails)||((this.versionGroupDetails!= null)&&this.versionGroupDetails.equals(rhs.versionGroupDetails))));
    }

    public void writeToParcel(android.os.Parcel dest, int flags) {
        dest.writeValue(move);
        dest.writeList(versionGroupDetails);
    }

    public int describeContents() {
        return  0;
    }

}
